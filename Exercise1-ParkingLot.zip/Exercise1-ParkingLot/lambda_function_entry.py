import json
import time
import uuid
import boto3

def lambda_handler(event, context):
    plate = event.get('queryStringParameters',{}).get('plate','undefined')
    parkingLot = event.get('queryStringParameters',{}).get('parkingLot','undefined')
    dynamodb = boto3.client('dynamodb')

    if(plate == 'undefined'):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'plate not specified'})
        }
    
    if(parkingLot == 'undefined'):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'parkingLot not specified'})
        }
    

    ticketId = str(uuid.uuid1())
    enterTime = str(time.time())

    dynamodb.put_item(TableName='Parking', Item={'ticketId':{'S': ticketId},'enterTime':{'N':enterTime},'plate':{'S':plate},'parkingLot':{'S':parkingLot}})

    
    return {
        'statusCode': 200,
        'body': json.dumps({'ticketId': ticketId})
    }
