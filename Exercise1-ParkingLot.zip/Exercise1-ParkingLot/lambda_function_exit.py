import json
import time
import uuid
import boto3

def lambda_handler(event, context):
    ticketId = event.get('queryStringParameters',{}).get('ticketId','undefined')
    dynamodb = boto3.client('dynamodb')

    if(ticketId == 'undefined'):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'ticketId not specified'})
        }
    

    info = dynamodb.get_item(TableName='Parking', Key={'ticketId':{'S':ticketId}})
    item = info.get('Item')
    if(item is None):
        return {
            'statusCode': 200,
            'body': json.dumps({'error': 'Invalid ticketId'})
        }
        
    enterTime = float(item.get('enterTime').get('N'))
    plate = (item.get('plate').get('S'))
    parkingLot = (item.get('parkingLot').get('S'))
    
    now = time.time()
    elapsed = now - enterTime
    
    totalParkedTimeMinuets = elapsed / 60
    price = int(totalParkedTimeMinuets / 15) * 2.5
    
    dynamodb.delete_item(TableName='Parking', Key={'ticketId':{'S':ticketId}})
 
    return {
        'statusCode': 200,
        'body': json.dumps({'plate': plate, 'totalParkedTimeMinuets': totalParkedTimeMinuets, 'parkingLot': parkingLot, 'price': price})
    }

